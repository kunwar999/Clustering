﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Data.SqlClient;
using System.Data;

namespace cure_clustering
{
    public partial class GraphComparison : Form
    {
        PartitioningResults partitioningResults = null;
        Setup setup=null;
        Merge merge = null;

        public GraphComparison(Setup setup,PartitioningResults partitioningResults, Merge merge)
        {
            long[] indexes = { 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29};
            InitializeComponent();
            this.partitioningResults = partitioningResults;
            this.setup = setup;
            this.merge = merge;
            Series Plain = chart1.Series.Add("Plain Query Execution");
            Plain.Points.DataBindXY( indexes,this.partitioningResults.microseconds1);
            Plain.ChartType = SeriesChartType.Line;
            Plain.Color = Color.Red;
            Plain.BorderWidth = 2;
            Series CURE = chart1.Series.Add("CURE Execution");
            CURE.Points.DataBindXY( indexes,this.partitioningResults.microseconds);
            CURE.ChartType = SeriesChartType.Line;
            CURE.Color = Color.DarkBlue;
            CURE.BorderWidth = 2;
           
        }

     
        private void button2_Click(object sender, EventArgs e)
        {
            this.merge.Show();
            this.Hide();
        }

        private void Merge_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            setup.Show();
        }

      
    }
}
